uhhhhhhh
just input data and wait
:)