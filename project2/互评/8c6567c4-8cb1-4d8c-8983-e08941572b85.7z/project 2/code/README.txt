# README.md

### Build the program

Use the "main.c" as the main code, ".h" as a header file, and ".c" as a source file to build the executable file.

Compiled Language Standards: C99

```
"main.h"

"main.c" ： the main code of the program

"point.h" 

"point.c" : the scan and record of the point array and the calculation of two limit factors 

"way.h" 

"way.c" : print the score array; to find the best way; to print the point which build up the path 
```



### Mode Introduction

Mode 1:

The method the exercise is given. To voting the path, I revise it better to distinguish the complete and incomplete path. And assign different situation different votes (showing above -- the coefficient constant PASS).

Mode 2: 

The New method I give. Using the result of delta distance and delta angle to assign different path different grades. by this, we can make the proper path contribute more to the results.



### ABOUT THE REPORT

Please open "*\Project 2\documents\Project1.pdf" to read the detailed report.



## Any Suggestions & Criticism are Welcome!

